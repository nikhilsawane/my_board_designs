# Board 2: Switching Noise with Good and Bad Layout

![Progress](https://img.shields.io/badge/Progress-0%25-red)

This branch contains the design files and documentation for **Board 2** of ECEN 5730 – Practical PCB Design.  
The purpose of this board is to **demonstrate how layout choices affect switching noise** and to practice **best measurement techniques** for capturing that noise.  

The board will contain **two identical hex inverter circuits**:  
- A **good layout** using best design practices (continuous ground plane, close decoupling).  
- A **bad layout** with poor practices (no ground plane under IC, ground routed as traces, decoupling capacitor far away).  

---

## 📖 References
- Course textbook: *Bogatin’s Practical Guide to Prototype Breadboard and PCB Design*  
- Chapters to review before Board 2: **2, 3, 4, 12, 13**  
- Labs to complete before Board 2: **Lab 4, 5, 7, 8, 9**  

---

## ✅ Board 2 Checklist

### Before Starting
- [X] Review required textbook chapters.  
- [X] Complete prerequisite labs.  

### Plan of Record (POR)
- [ ] Rough schematic / block diagram.  
- [ ] List of significant parts + datasheets (AMS1117, 74AHC14, 555, LEDs, resistors, capacitors).  
- [ ] Define **“what it means to work.”**  
- [ ] Create a project schedule (CDR, file submission, bring-up).  
- [ ] Write a test/characterization plan (plots to capture, quiet hi/lo measurements, noise comparisons).  
- [ ] Power budget calculation (5 V input → 3.3 V via LDO).  
- [ ] Identify risks + mitigations.  

### Design (Schematic + Layout)
- [X] Two hex inverter circuits (good vs bad).  
- [X] 555 timer → ~500 Hz, 50% duty clock.  
- [X] Switch to select good vs bad inverter input.  
- [X] Tie unused inputs HIGH (~10k pull-ups).  
- [X] LEDs + 50Ω loads on outputs.  
- [X] Scope trigger output.  
- [X] Quiet HIGH and quiet LOW inverters.  
- [ ] Current estimates for LED loads.  
- [ ] Thevenin resistance measurement plan.  
- [X] Indicator LEDs + isolation switches + test points.  
- [X] Grad students: 3.3 V / 5 V switch for inverters.  
- [X] Only 1206 package passives + LEDs.  

### Layout Rules
- [X] Keep placement identical between good and bad regions.  
- [X] Label all test points + indicators.  
- [X] Board size ≤ 3.9" × 3.9".  
- [X] Price ≤ $2 at JLCPCB.  
- [X] Good layout: continuous ground plane.  
- [X] Bad layout: no plane (use traces).  
- [X] Minimal cross-unders, keep them short.  
- [X] Proper decoupling placement (close vs far).  
- [X] Add your **name** to board + zip file.  

### Bring-Up & Test
- [ ] Inspect bare board (shorts, opens, resistance check).  
- [ ] Assemble in stages (power → 555 → inverter A → inverter B).  
- [ ] Verify 5 V rail, 3.3 V LDO.  
- [ ] Measure 555 output (frequency, duty cycle).  
- [ ] Confirm inverter operation (LED toggling).  
- [ ] Capture rise/fall times.  
- [ ] Compare quiet HIGH vs quiet LOW noise (good vs bad).  
- [ ] Compare rail noise vs quiet HIGH.  
- [ ] Grad students: rail compression measurement.  
- [ ] Save labeled scope plots (consistent colors: green = good, yellow = bad).  

### Final Report
- [ ] POR with expectations + block diagram.  
- [ ] Final schematic + layout screenshots.  
- [ ] Pictures of bare board + assembled board.  
- [ ] Test results + scope plots.  
- [ ] Analysis: what worked, what didn’t, recommendations.  
- [ ] Extra credit (optional):  
  - [ ] Thevenin resistance measurement.  
  - [ ] LDO oscillation demo.  
  - [ ] 3.3 V vs 5 V inverter performance.  

---

## 🚀 Workflow
1. Work through the checklist while designing.  
2. Commit schematic, layout, and test documentation to this branch.  
3. Submit design files after CDR sign-off.  
4. Assemble, test, and document results for the final report.  

---

## 📝 Notes
- Use **best measurement practices** with 10× probe test points.  
- Keep scope plots **clear, labeled, and on consistent scales**.  
- The final report is worth **10 points (midterm grade)** and will be a strong addition to your portfolio.  
